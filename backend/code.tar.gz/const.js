module.exports = {
    db: {
        id: '64e5bca5774c43c6e4b8',
        listings_id: '64e5bcac74d34020c488',
        users_id: 'users',
    },
}
